@extends('master')

@section('content')
<!-- DATA TABLE-->
<h3 class="title-5 m-b-35">Toko Obat</h3>
<div class="table-data__tool">
    <div class="table-data__tool-left">
        <div class="rs-select2--light rs-select2--md">
          <button class="au-btn au-btn-icon au-btn--green au-btn--small">
              <i class="zmdi zmdi-plus"></i>add item</button>
            <div class="dropDownSelect2"></div>
        </div>
<div class="table-responsive m-b-40">
    <table class="table table-borderless table-data3">
        <thead>
            <tr>
                <th>Date</th>
                <th>Type</th>
                <th>Description</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>2018-09-29 05:57</td>
                <td>Mobile</td>
                <td>iPhone X 64Gb Grey</td>
                <td class="process">Processed</td>
                <td>
                      <button type="submit" class="btn btn-primary btn-sm">
                          <i class="fa fa-dot-circle-o"></i> Update
                      </button>
                      <button type="reset" class="btn btn-danger btn-sm">
                          <i class="fa fa-ban"></i> Delete
                      </button>
                </td>
            </tr>

        </tbody>
    </table>
</div>
<!-- END DATA TABLE-->
@endsection
