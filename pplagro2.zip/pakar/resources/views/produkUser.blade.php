@extends('master')

@section('content')
<!-- MENU SIDEBAR-->
<aside class="menu-sidebar d-none d-lg-block">
    <div class="logo">
        <a href="#">
            <img src="images/icon/logo.png" alt="Cool Admin" />
        </a>
    </div>
    <div class="menu-sidebar__content js-scrollbar1">
        <nav class="navbar-sidebar">
            <ul class="list-unstyled navbar__list">
                <li>
                    <a class="js-arrow" href="{{url('/home')}}">
                        <i class="fas fa-users"></i>Dokter</a>
                </li>
                <li  class="active has-sub">
                    <a href="{{url('/produkUser')}}">
                        <i class="fas fa-pills"></i>Obat</a>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-comments"></i>Chat</a>
                </li>
                <li>
                    <a href="{{url('/keranjangUser')}}">
                        <i class="fas fa-shopping-cart"></i>Keranjang</a>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-user-md"></i>Diagnosa</a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<!-- END MENU SIDEBAR-->
<!-- DATA TABLE-->
<h3 class="title-5 m-b-35">Toko Obat</h3>
<div class="table-data__tool">

<div class="table-responsive m-b-40">
  <form class="login100-form validate-form" method="POST">
    @csrf
    <table class="table table-borderless table-data3">
        <thead>
            <tr>
                <th>#</th>
                <th>Produk</th>
                <th>Stock</th>
                <th>Price</th>
                <th>Doctor</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
          <?php $number = 0; ?>
          @foreach($produk as $p)
            <tr>
                <td>{{++$number}}.</td>
                <td>{{ $p->name_produk }}</td>
                <td>{{ $p->stock_produk }}</td>
                <td>Rp.{{ $p->price_produk }}</td>
                <td>Dr. {{ $p->user->name}}</td>
                <td>
                    <form action="#" method="POST">
                      <a href="#" class="btn btn-primary btn-sm">
                          <i class="fas fa-shopping-cart"></i>
                      </a>
                      </form>
                </td>
            </tr>
          @endforeach
        </tbody>
    </table>
  </form>
</div>
<!-- END DATA TABLE-->
@endsection
