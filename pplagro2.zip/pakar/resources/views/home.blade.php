@extends('master')

@section('content')
  @if(Auth::user()->hasAnyRole('Admin'))
  <!-- MENU SIDEBAR-->
  <aside class="menu-sidebar d-none d-lg-block">
      <div class="logo">
          <a href="#">
              <img src="images/icon/logo.png" alt="Cool Admin" />
          </a>
      </div>
      <div class="menu-sidebar__content js-scrollbar1">
          <nav class="navbar-sidebar">
              <ul class="list-unstyled navbar__list">
                  <li class="active has-sub">
                      <a class="js-arrow" href="#">
                          <i class="fas fa-users"></i>Dokter</a>
                  </li>
                  <li>
                      <a href="#">
                          <i class="fas fa-pills"></i>Obat</a>
                  </li>
                  <li>
                      <a href="#">
                          <i class="fas fa-comments"></i>Chat</a>
                  </li>
                  <li>
                      <a href="{{url('/keranjangUser')}}">
                          <i class="fas fa-shopping-cart"></i>Keranjang</a>
                  </li>
                  <li>
                      <a href="#">
                          <i class="fas fa-user-md"></i>Diagnosa</a>
                  </li>
              </ul>
          </nav>
      </div>
  </aside>
  <!-- END MENU SIDEBAR-->

  <!-- DATA TABLE-->
  <div class="table-data__tool-left">
      <div class="rs-select2--light rs-select2--md"></div>
      <h3 class="title-5 m-b-35">Daftar Nama Dokter</h3>
  <div class="table-data__tool">
  <div class="table-responsive m-b-40">
      <table class="table table-borderless table-data3">
          <thead>
              <tr>
                  <th>#</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>Tanggal Lahir</th>
                  <th>Jenis Kelamin</th>
                  <th>Alamat</th>
              </tr>
          </thead>
          <tbody>
                <?php $number = 0; ?>
                @foreach($dokter as $data)
                @foreach($data['users'] as $data)
                <tr>
                  <td>{{++$number}}.</td>
                  <td>Dr. {{$data->name}}</td>
                  <td>{{$data->email}}</td>
                  <td>{{$data->tanggal_lahir}}</td>
                  <td>{{$data->JenisKelamin}}</td>
                  <td>{{$data->alamat}}</td>
                </tr>
                @endforeach
                @endforeach
          </tbody>
      </table>
  </div>
  <!-- END DATA TABLE-->

  @elseif(Auth::user()->hasAnyRole('Dokter'))
  <!-- MENU SIDEBAR-->
  <aside class="menu-sidebar d-none d-lg-block">
      <div class="logo">
          <a href="#">
              <img src="images/icon/logo.png" alt="Cool Admin" />
          </a>
      </div>
      <div class="menu-sidebar__content js-scrollbar1">
          <nav class="navbar-sidebar">
              <ul class="list-unstyled navbar__list">
                  <li class="active has-sub">
                      <a class="js-arrow" href="{{url('/home')}}">
                          <i class="fas fa-users"></i>Dokter</a>
                  </li>
                  <li>
                      <a href="{{url('/produk')}}">
                          <i class="fas fa-pills"></i>Obat</a>
                  </li>
                  <li>
                      <a href="#">
                          <i class="fas fa-comments"></i>Chat</a>
                  </li>
                  <li>
                      <a href="#">
                          <i class="fas fa-user-md"></i>Diagnosa</a>
                  </li>
              </ul>
          </nav>
      </div>
  </aside>
  <!-- END MENU SIDEBAR-->
  <!-- DATA TABLE-->
  <div class="table-data__tool-left">
      <div class="rs-select2--light rs-select2--md"></div>
      <h3 class="title-5 m-b-35">Daftar Nama Dokter</h3>
  <div class="table-data__tool">
  <div class="table-responsive m-b-40">
      <table class="table table-borderless table-data3">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Tanggal Lahir</th>
                <th>Jenis Kelamin</th>
                <th>Alamat</th>
            </tr>
        </thead>
        <tbody>
              <?php $number = 0; ?>
              @foreach($dokter as $data)
              @foreach($data['users'] as $data)
              <tr>
                <td>{{++$number}}.</td>
                <td>Dr. {{$data->name}}</td>
                <td>{{$data->email}}</td>
                <td>{{$data->tanggal_lahir}}</td>
                <td>{{$data->JenisKelamin}}</td>
                <td>{{$data->alamat}}</td>
              </tr>
              @endforeach
              @endforeach
        </tbody>
      </table>
  </div>
  <!-- END DATA TABLE-->

  @else(Auth::user()->hasAnyRole('Peternak'))
  <!-- MENU SIDEBAR-->
  <aside class="menu-sidebar d-none d-lg-block">
      <div class="logo">
          <a href="#">
              <img src="images/icon/logo.png" alt="Cool Admin" />
          </a>
      </div>
      <div class="menu-sidebar__content js-scrollbar1">
          <nav class="navbar-sidebar">
              <ul class="list-unstyled navbar__list">
                  <li class="active has-sub">
                      <a class="js-arrow" href="{{url('/home')}}">
                          <i class="fas fa-users"></i>Dokter</a>
                  </li>
                  <li>
                      <a href="{{url('/produkUser')}}">
                          <i class="fas fa-pills"></i>Obat</a>
                  </li>
                  <li>
                      <a href="#">
                          <i class="fas fa-comments"></i>Chat</a>
                  </li>
                  <li>
                      <a href="{{url('/keranjangUser')}}">
                          <i class="fas fa-shopping-cart"></i>Keranjang</a>
                  </li>
                  <li>
                      <a href="#">
                          <i class="fas fa-user-md"></i>Diagnosa</a>
                  </li>
              </ul>
          </nav>
      </div>
  </aside>
  <!-- END MENU SIDEBAR-->

  <!-- DATA TABLE-->
  <div class="table-data__tool-left">
      <div class="rs-select2--light rs-select2--md"></div>
        <h3 class="title-5 m-b-35">Daftar Nama Dokter</h3>
  <div class="table-data__tool">
  <div class="table-responsive m-b-40">
      <table class="table table-borderless table-data3">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Tanggal Lahir</th>
                <th>Jenis Kelamin</th>
                <th>Alamat</th>
            </tr>
        </thead>
        <tbody>
              <?php $number = 0; ?>
              @foreach($dokter as $data)
              @foreach($data['users'] as $data)
              <tr>
                <td>{{++$number}}.</td>
                <td>Dr. {{$data->name}}</td>
                <td>{{$data->email}}</td>
                <td>{{$data->tanggal_lahir}}</td>
                <td>{{$data->JenisKelamin}}</td>
                <td>{{$data->alamat}}</td>
              </tr>
              @endforeach
              @endforeach
        </tbody>
      </table>
  </div>
  <!-- END DATA TABLE-->
  @endif
@endsection
