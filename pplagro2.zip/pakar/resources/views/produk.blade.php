@extends('master')

@section('content')
<!-- MENU SIDEBAR-->
<aside class="menu-sidebar d-none d-lg-block">
    <div class="logo">
        <a href="#">
            <img src="images/icon/logo.png" alt="Cool Admin" />
        </a>
    </div>
    <div class="menu-sidebar__content js-scrollbar1">
        <nav class="navbar-sidebar">
            <ul class="list-unstyled navbar__list">
                <li>
                    <a class="js-arrow" href="{{url('/home')}}">
                        <i class="fas fa-users"></i>Dokter</a>
                </li>
                <li  class="active has-sub">
                    <a href="{{url('/produk')}}">
                        <i class="fas fa-pills"></i>Obat</a>
                </li>
                <li>
                    <a href="table.html">
                        <i class="fas fa-comments"></i>Chat</a>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-user-md"></i>Diagnosa</a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<!-- END MENU SIDEBAR-->
<!-- DATA TABLE-->
<h3 class="title-5 m-b-35">Toko Obat</h3>
<div class="table-data__tool-left">
    <div class="rs-select2--light rs-select2--md">
      <a href="{{route('produk.create')}}" class="au-btn au-btn-icon au-btn--green au-btn--small">
          <i class="fa fa-plus-circle"></i>Tambah Item</a>
        <div class="dropDownSelect2"></div>
    </div>
<div class="table-data__tool">
<div class="table-responsive m-b-40">
  <form class="login100-form validate-form" method="POST">
    @csrf
    <table class="table table-borderless table-data3">
        <thead>
            <tr>
                <th>#</th>
                <th>Produk</th>
                <th>Stock</th>
                <th>Price</th>
                <th>Doctor</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
          <?php $number = 0; ?>
          @foreach($produk as $p)
            <tr>
                <td>{{ ++$number }}.</td>
                <td>{{ $p->name_produk }}</td>
                <td>{{ $p->stock_produk }}</td>
                <td>Rp.{{ $p->price_produk }}</td>
                <td>Dr. {{$p->user->name}}</td>
                <td>
                        <a href="{{url('delete/'.$p->id)}}" type="submit" class="btn btn-danger btn-sm">
                            <i class="fa fa-trash"></i> Hapus
                        </a>
                        <a href="/produk/{{$p->id}}/edit" class="btn btn-primary btn-sm">
                            <i class="fa fa-pencil-alt"></i> Ubah
                        </a>
                </td>
            </tr>
          @endforeach
        </tbody>
    </table>
  </form>
</div>
<!-- END DATA TABLE-->
@endsection
