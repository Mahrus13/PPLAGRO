<?php $__env->startSection('content'); ?>
  <?php if(Auth::user()->hasAnyRole('Admin')): ?>
  <!-- MENU SIDEBAR-->
  <aside class="menu-sidebar d-none d-lg-block">
      <div class="logo">
          <a href="#">
              <img src="images/icon/logo.png" alt="Cool Admin" />
          </a>
      </div>
      <div class="menu-sidebar__content js-scrollbar1">
          <nav class="navbar-sidebar">
              <ul class="list-unstyled navbar__list">
                  <li class="active has-sub">
                      <a class="js-arrow" href="#">
                          <i class="fas fa-users"></i>Dokter</a>
                  </li>
                  <li>
                      <a href="#">
                          <i class="fas fa-pills"></i>Obat</a>
                  </li>
                  <li>
                      <a href="#">
                          <i class="fas fa-comments"></i>Chat</a>
                  </li>
                  <li>
                      <a href="<?php echo e(url('/keranjangUser')); ?>">
                          <i class="fas fa-shopping-cart"></i>Keranjang</a>
                  </li>
                  <li>
                      <a href="#">
                          <i class="fas fa-user-md"></i>Diagnosa</a>
                  </li>
              </ul>
          </nav>
      </div>
  </aside>
  <!-- END MENU SIDEBAR-->

  <!-- DATA TABLE-->
  <div class="table-data__tool-left">
      <div class="rs-select2--light rs-select2--md"></div>
      <h3 class="title-5 m-b-35">Daftar Nama Dokter</h3>
  <div class="table-data__tool">
  <div class="table-responsive m-b-40">
      <table class="table table-borderless table-data3">
          <thead>
              <tr>
                  <th>#</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>Tanggal Lahir</th>
                  <th>Jenis Kelamin</th>
                  <th>Alamat</th>
              </tr>
          </thead>
          <tbody>
                <?php $number = 0; ?>
                <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $data['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e(++$number); ?>.</td>
                  <td>Dr. <?php echo e($data->name); ?></td>
                  <td><?php echo e($data->email); ?></td>
                  <td><?php echo e($data->tanggal_lahir); ?></td>
                  <td><?php echo e($data->JenisKelamin); ?></td>
                  <td><?php echo e($data->alamat); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
  </div>
  <!-- END DATA TABLE-->

  <?php elseif(Auth::user()->hasAnyRole('Dokter')): ?>
  <!-- MENU SIDEBAR-->
  <aside class="menu-sidebar d-none d-lg-block">
      <div class="logo">
          <a href="#">
              <img src="images/icon/logo.png" alt="Cool Admin" />
          </a>
      </div>
      <div class="menu-sidebar__content js-scrollbar1">
          <nav class="navbar-sidebar">
              <ul class="list-unstyled navbar__list">
                  <li class="active has-sub">
                      <a class="js-arrow" href="<?php echo e(url('/home')); ?>">
                          <i class="fas fa-users"></i>Dokter</a>
                  </li>
                  <li>
                      <a href="<?php echo e(url('/produk')); ?>">
                          <i class="fas fa-pills"></i>Obat</a>
                  </li>
                  <li>
                      <a href="#">
                          <i class="fas fa-comments"></i>Chat</a>
                  </li>
                  <li>
                      <a href="#">
                          <i class="fas fa-user-md"></i>Diagnosa</a>
                  </li>
              </ul>
          </nav>
      </div>
  </aside>
  <!-- END MENU SIDEBAR-->
  <!-- DATA TABLE-->
  <div class="table-data__tool-left">
      <div class="rs-select2--light rs-select2--md"></div>
      <h3 class="title-5 m-b-35">Daftar Nama Dokter</h3>
  <div class="table-data__tool">
  <div class="table-responsive m-b-40">
      <table class="table table-borderless table-data3">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Tanggal Lahir</th>
                <th>Jenis Kelamin</th>
                <th>Alamat</th>
            </tr>
        </thead>
        <tbody>
              <?php $number = 0; ?>
              <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $data['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e(++$number); ?>.</td>
                <td>Dr. <?php echo e($data->name); ?></td>
                <td><?php echo e($data->email); ?></td>
                <td><?php echo e($data->tanggal_lahir); ?></td>
                <td><?php echo e($data->JenisKelamin); ?></td>
                <td><?php echo e($data->alamat); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
  </div>
  <!-- END DATA TABLE-->

  <?php else: ?>
  <!-- MENU SIDEBAR-->
  <aside class="menu-sidebar d-none d-lg-block">
      <div class="logo">
          <a href="#">
              <img src="images/icon/logo.png" alt="Cool Admin" />
          </a>
      </div>
      <div class="menu-sidebar__content js-scrollbar1">
          <nav class="navbar-sidebar">
              <ul class="list-unstyled navbar__list">
                  <li class="active has-sub">
                      <a class="js-arrow" href="<?php echo e(url('/home')); ?>">
                          <i class="fas fa-users"></i>Dokter</a>
                  </li>
                  <li>
                      <a href="<?php echo e(url('/produkUser')); ?>">
                          <i class="fas fa-pills"></i>Obat</a>
                  </li>
                  <li>
                      <a href="#">
                          <i class="fas fa-comments"></i>Chat</a>
                  </li>
                  <li>
                      <a href="<?php echo e(url('/keranjangUser')); ?>">
                          <i class="fas fa-shopping-cart"></i>Keranjang</a>
                  </li>
                  <li>
                      <a href="#">
                          <i class="fas fa-user-md"></i>Diagnosa</a>
                  </li>
              </ul>
          </nav>
      </div>
  </aside>
  <!-- END MENU SIDEBAR-->

  <!-- DATA TABLE-->
  <div class="table-data__tool-left">
      <div class="rs-select2--light rs-select2--md"></div>
        <h3 class="title-5 m-b-35">Daftar Nama Dokter</h3>
  <div class="table-data__tool">
  <div class="table-responsive m-b-40">
      <table class="table table-borderless table-data3">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Tanggal Lahir</th>
                <th>Jenis Kelamin</th>
                <th>Alamat</th>
            </tr>
        </thead>
        <tbody>
              <?php $number = 0; ?>
              <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $data['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e(++$number); ?>.</td>
                <td>Dr. <?php echo e($data->name); ?></td>
                <td><?php echo e($data->email); ?></td>
                <td><?php echo e($data->tanggal_lahir); ?></td>
                <td><?php echo e($data->JenisKelamin); ?></td>
                <td><?php echo e($data->alamat); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
  </div>
  <!-- END DATA TABLE-->
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pakar\resources\views//home.blade.php ENDPATH**/ ?>