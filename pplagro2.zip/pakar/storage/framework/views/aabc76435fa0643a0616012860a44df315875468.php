<?php $__env->startSection('content'); ?>
<!-- MENU SIDEBAR-->
<aside class="menu-sidebar d-none d-lg-block">
    <div class="logo">
        <a href="#">
            <img src="images/icon/logo.png" alt="Cool Admin" />
        </a>
    </div>
    <div class="menu-sidebar__content js-scrollbar1">
        <nav class="navbar-sidebar">
            <ul class="list-unstyled navbar__list">
                <li>
                    <a class="js-arrow" href="<?php echo e(url('/home')); ?>">
                        <i class="fas fa-users"></i>Dokter</a>
                </li>
                <li  class="active has-sub">
                    <a href="<?php echo e(url('/produk')); ?>">
                        <i class="fas fa-pills"></i>Obat</a>
                </li>
                <li>
                    <a href="table.html">
                        <i class="fas fa-comments"></i>Chat</a>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-user-md"></i>Diagnosa</a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<!-- END MENU SIDEBAR-->
<!-- DATA TABLE-->
<h3 class="title-5 m-b-35">Toko Obat</h3>
<div class="table-data__tool-left">
    <div class="rs-select2--light rs-select2--md">
      <a href="<?php echo e(route('produk.create')); ?>" class="au-btn au-btn-icon au-btn--green au-btn--small">
          <i class="fa fa-plus-circle"></i>Tambah Item</a>
        <div class="dropDownSelect2"></div>
    </div>
<div class="table-data__tool">
<div class="table-responsive m-b-40">
  <form class="login100-form validate-form" method="POST">
    <?php echo csrf_field(); ?>
    <table class="table table-borderless table-data3">
        <thead>
            <tr>
                <th>#</th>
                <th>Produk</th>
                <th>Stock</th>
                <th>Price</th>
                <th>Doctor</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
          <?php $number = 0; ?>
          <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$number); ?>.</td>
                <td><?php echo e($p->name_produk); ?></td>
                <td><?php echo e($p->stock_produk); ?></td>
                <td>Rp.<?php echo e($p->price_produk); ?></td>
                <td>Dr. <?php echo e($p->user->name); ?></td>
                <td>
                        <a href="<?php echo e(url('delete/'.$p->id)); ?>" type="submit" class="btn btn-danger btn-sm">
                            <i class="fa fa-trash"></i> Hapus
                        </a>
                        <a href="/produk/<?php echo e($p->id); ?>/edit" class="btn btn-primary btn-sm">
                            <i class="fa fa-pencil-alt"></i> Ubah
                        </a>
                </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
  </form>
</div>
<!-- END DATA TABLE-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pakar\resources\views/produk.blade.php ENDPATH**/ ?>