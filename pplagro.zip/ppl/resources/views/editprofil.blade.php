<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>PROFIL</title>
  </head>
  <body>
  <form action="{{ route('editproses') }}">
    @foreach ($data as $key => $nama)
    <input type="text" name="hasil" value='{{ $nama->nama_pengguna}}'>
    <input type="text" name="hasil1" value='{{ $nama->nama}}'>
    <input type="text" name="hasil2" value='{{ $nama->kata_sandi}}'>
    <input type="text" name="hasil3" value='{{ $nama->tanggal_lahir}}'>
    <input type="text" name="hasil4" value='{{ $nama->alamat}}'>
    @endforeach
    <input id="submit-btn" type="submit" name="submit" value="SIMPAN" />
  </form>
  </body>
</html>
