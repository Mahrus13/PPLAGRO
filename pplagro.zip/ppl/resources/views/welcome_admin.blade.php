<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="assets/style.css" rel='stylesheet' type='text/css' />
<!--webfonts-->
<link href='http://fonts.googleapis.com/css?family=Oxygen:400,300,700|Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
<!--//webfonts-->
</head>

<body>
    <div class="main">
        <div class="user">
            <img src="images/user.png" alt="">
        </div>
        <!---start-main-->
        <div class="login">
            <div class="inset">
                <span>Selamat Datang ADMIN | <a href="login">Logout?</a></span>
            </div>
        </div>
        <!---//end-main-->
    </div>
</body>
</html>
