<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<h2>OBAT SAPI</h2>

	<a href="/tampilan_obat/tambahObat"> + Tambah Obat Baru</a>

	<br/>
	<br/>

	<table border="1">
		<tr>
			<th>Nama Obat</th>
			<th>Stock</th>
			<th>Harga</th>
			<th>Nama Dokter</th>
			<th>Opsi</th>
		</tr>
		@foreach($obat as $o)
		<tr>
			<td>{{ $o->nama_obat }}</td>
			<td>{{ $o->stock_obat }}</td>
			<td>{{ $o->harga }}</td>
			<td>{{ $o->nama_pengguna_dokter }}</td>
			<td>
				<a href="/tampilan_obat/edit/{{ $o->id }}">Ubah</a>
				|
				<a href="/tampilan_obat/hapus/{{ $o->id }}">Hapus</a>
			</td>
		</tr>
		@endforeach
	</table>
	<a href="home_dokter">Kembali</a>

</body>
</html>
