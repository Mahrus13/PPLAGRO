@extends('template1')
<title>MASUK</title>
@section('content')
<div id="card-content">
    <div id="card-title">
    <h2>MASUK</h2>
    <div class="underline-title"></div>
    </div>
</div>
<form method="POST" class="form" action="{{ route('prosesUser2') }}">
  <input type="hidden" name="_token" value="{{ csrf_token() }}">
    <label for="nama_pengguna" style="padding-top:13px">&nbsp;Nama Pengguna</label>
    <input id="nama_pengguna" class="form-content" type="text" name="nama_pengguna"required />
    <div class="form-border"></div>
    <label for="kata_sandi" style="padding-top:22px">&nbsp;Kata Sandi</label>
    <input id="kata_sandi"class="form-content" type="password" name="kata_sandi" required />
    <div class="form-border"></div>
    <input id="submit-btn" type="submit" name="submit" value="MASUK" />
</form>
@endsection
