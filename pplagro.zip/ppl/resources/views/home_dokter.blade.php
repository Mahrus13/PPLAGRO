<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/home1.css">
    <title>Si Sapi</title>
  </head>
  <body>
    <ul>
    <li class="dropdown">
      <a class="dropbtn"></a>
      <div class="dropdown-content">
        <a href="{{route ('edit')}}">Profil Saya</a>
        <a href="login_dokter">Keluar</a>
      </div>
    </li>
  </ul>
    @yield('content')
    <div class="box1"></div>
	  <a href="tampilan_obat">	<div class="box2"></div> </a>
		<div class="box3"></div>
    <div class="box4"></div>
    <div class="judul1">DOKTER</div>
    <div class="judul2">OBAT</div>
    <div class="judul3">PESAN</div>

  </body>
</html>
