<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>PROFIL</title>
  </head>
  <body>
    <table border="1px">
      <tr>
        <td>nama pengguna</td>
        <td>nama</td>
        <td>kata sandi</td>
        <td>tanggal lahir</td>
        <td>alamats</td>
      @foreach ($data as $key => $nama)
          <tr>
              <td>{{ $nama->nama_pengguna}}</td>
              <td>{{ $nama->nama}}</td>
              <td>{{ $nama->kata_sandi}}</td>
              <td>{{ $nama->tanggal_lahir}}</td>
              <td>{{ $nama->alamat}}</td>
          </tr>
      @endforeach
      </tr>
    </table>
    <a href="{{route('editq')}}"> <input type="submit" name="" value="Ubah"> </a>
  </body>
</html>
