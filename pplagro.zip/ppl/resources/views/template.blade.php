<!DOCTYPE html>
<html>
 <head>
  <title></title>
  <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
  <link rel="stylesheet" href="css/login.css">
  <style></style>
 </head>
 <body>
      <a href="login"><div id="gambar"></div></a>
      <div id="card">
      @yield('content')
      </div>

 </body>
</html>
