<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


	<h3>Edit Obat</h3>

	<a href="/tampilan_obat"> Kembali</a>

	<br/>
	<br/>

	@foreach($obat as $o)
	<form action="/tampilan_obat/update" method="post">
		{{ csrf_field() }}
		<input type="hidden" name="id" value="{{ $o->id }}"> <br/>
		Nama Obat <input type="text" required="required" name="nama_obat" value="{{ $o->nama_obat }}"> <br/>
		Stock Obat <input type="number" required="required" name="stock_obat" value="{{ $o->stock_obat }}"> <br/>
		Harga <input type="number" required="required" name="harga" value="{{ $o->harga }}"> <br/>
		Nama Dokter <input type="text" required="required" name="nama_dokter" value="{{ $o->nama_pengguna_dokter }}"> <br/>
		<input type="submit" value="Simpan Data">
	</form>
	@endforeach


</body>
</html>
