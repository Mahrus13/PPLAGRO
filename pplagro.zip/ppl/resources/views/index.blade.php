@extends('template1')
<title>SI SAPI</title>
@section('content')
<div id="card-content">
    <div id="card-title">
    <h2>MASUK SEBAGAI :</h2>
    <div class="underline-titleo"></div>
    </div>
</div>
  <a href="login_dokter"><button class="button button2">DOKTER</button> </a>
  <a href="login"> <button class="button button3">PETERNAK</button> </a>
@endsection
