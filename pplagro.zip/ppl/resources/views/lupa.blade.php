@extends('template')
<title>LUPA PASSWORD</title>
@section('content')
<div id="card-content">
    <div id="card-title">
    <h2>LUPA PASSWORD</h2>
    <div class="underline-titlee"></div>
    </div>
</div>
<form method="post" class="form">
  <label for="nama_pengguna" style="padding-top:13px">&nbsp;Nama Pengguna</label>
  <input id="nama_pengguna" class="form-content" type="text" name="nama_pengguna"required />
  <div class="form-border"></div>
  <label for="kata_sandi" style="padding-top:22px">&nbsp;Kata Sandi</label>
  <input id="kata_sandi"class="form-content" type="password" name="kata_sandi" required />
  <div class="form-border"></div>
  <label for="kata_sandi1" style="padding-top:22px">&nbsp;Konfirm Kata Sandi</label>
  <input id="kata_sandi1"class="form-content" type="password" name="kata_sandi1" required />
  <div class="form-border"></div>
  <input id="submit-btn" type="submit" name="submit" value="SIMPAN" />
</form>
@endsection
