<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ObatController extends Controller
{
  public function index()
  {
    // mengambil data dari table pegawai
    $obat = DB::table('obat')->get();

    // mengirim data pegawai ke view index
    return view('tampilan_obat',['obat' => $obat]);

  }
  // method untuk menampilkan view form tambah pegawai
public function tambah()
{

	// memanggil view tambah
	return view('tambahObat');

}
// method untuk insert data ke table pegawai
public function store(Request $request)
{
	// insert data ke table pegawai
	DB::table('obat')->insert([
		'nama_obat' => $request->nama_obat,
		'stock_obat' => $request->stock_obat,
		'harga' => $request->harga,
		'nama_pengguna_dokter' => $request->nama_dokter
	]);
	// alihkan halaman ke halaman pegawai
	return redirect('/tampilan_obat');
}
  // method untuk edit data pegawai
  public function edit($id)
  {
  // mengambil data pegawai berdasarkan id yang dipilih
  $obat = DB::table('obat')->where('id',$id)->get();
  // passing data pegawai yang didapat ke view edit.blade.php
  return view('editObat',['obat' => $obat]);

  }
  // update data pegawai
  public function update(Request $request)
  {
  	// update data pegawai
  	DB::table('obat')->where('id',$request->id)->update([
  		'nama_obat' => $request->nama_obat,
  		'stock_obat' => $request->stock_obat,
  		'harga' => $request->harga,
  		'nama_pengguna_dokter' => $request->nama_dokter
  	]);
  	// alihkan halaman ke halaman pegawai
  	return redirect('/tampilan_obat');
  }
  // method untuk hapus data pegawai
public function hapus($id)
{
	// menghapus data pegawai berdasarkan id yang dipilih
	DB::table('obat')->where('id',$id)->delete();

	// alihkan halaman ke halaman pegawai
	return redirect('/tampilan_obat');
}
}
