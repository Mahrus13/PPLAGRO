<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class koneksi extends Controller
{
  //login petani
  public function proses1(){
    $find = DB::select("SELECT * FROM petani where nama_pengguna=? and kata_sandi=?",[$nama_pengguna = $_POST['nama_pengguna'], $kata_Sandi = $_POST['kata_sandi']]);
    if (count($find) != 0) {
      echo "<script>alert('SELAMAT DATANG, USER')</script>";
      return view('home');
    }else {
      echo "<script>alert('DATA TIDAK ADA.')</script>";
      return view('login');
    }
  }

  //login dokter
  public function proses2(){
    $find = DB::select("SELECT * FROM dokter where nama_pengguna=? and kata_sandi=?",[$nama_pengguna = $_POST['nama_pengguna'], $kata_Sandi = $_POST['kata_sandi']]);
    if (count($find) != 0) {
      if ($nama_pengguna == 'admin') {
        echo "<script>alert('SELAMAT DATANG, ADMIN .')</script>";
        return view('home_dokter');
      }else {
        echo "<script>alert('SELAMAT DATANG, DOKTER .')</script>";
        return view('home_dokter');
      }
    }else {
      echo "<script>alert('DATA TIDAK ADA.')</script>";
      return view('login_dokter');
    }
  }

  //register petani
  public function proses(){
   $find = DB::select("SELECT * FROM petani where nama_pengguna=?",[$_POST['nama_pengguna']]);
    if(count($find)==0){
      $nama_pengguna = $_POST['nama_pengguna'];
      $nama = $_POST['nama'];
      $kata_Sandi = $_POST['kata_sandi'];
      $alamat = $_POST['alamat'];
      $input= DB::insert("INSERT INTO petani (nama_pengguna, nama, kata_sandi, alamat ) VALUES (?,?,?,?)",[$nama_pengguna, $nama, $kata_Sandi, $alamat]);
   }else {
     echo "<script>alert('DATA SUDAH ADA.')</script>";
     return view('daftar');
   }
   echo "<script>alert('BERHASIL DAFTAR.')</script>";
     return view('login');
  }

  //edit
  public function edit(){
    $find = DB::select("SELECT * FROM dokter where id='2'");
    return view('profile', ['data' => $find]);
  }

  public function editq(){
    $find = DB::select("SELECT * FROM dokter where id='2'");
    return view('editprofil', ['data' => $find]);
  }

  //editproses
  public function editproses(){
    $nama_pengguna = $_GET['hasil'];
    $nama = $_GET['hasil1'];
    $kata_Sandi = $_GET['hasil2'];
    $tanggal_lahir = $_GET['hasil3'];
    $alamat = $_GET['hasil4'];
    $pros= DB::update("UPDATE dokter set nama_pengguna=?, nama=?, kata_sandi=?, tanggal_lahir=?, alamat=? where id='2'",[$nama_pengguna, $nama, $kata_Sandi, $tanggal_lahir, $alamat]);
    echo "<script>alert('Data Sudah di perbarui.')</script>";
    return view('home_dokter');
  }

  //editobat
  public function editobat(){
    $find = DB::select("SELECT * FROM obat");
    return view('obat', ['data' => $find]);
  }

  public function editobatq(){
    $find = DB::select("SELECT * FROM obat");
    return view('editObat', ['data' => $find]);
  }

  //editproses1
  public function editproses1(){
    $nama_obat = $_GET['hasil'];
    $stock_obat = $_GET['hasil1'];
    $harga = $_GET['hasil2'];
    $nama_pengguna_dokter = $_GET['hasil3'];
    $pros= DB::update("UPDATE obat set nama_obat=?, stock_obat=?, harga=?, nama_pengguna_dokter=?",[$nama_obat, $stock_obat, $harga, $nama_pengguna_dokter]);
    echo "<script>alert('Data Sudah di perbarui.')</script>";
    return view('home_dokter');
  }

  // //tambah obat
  // public function tambah(){
  //  $find = DB::select("SELECT * FROM obat where nama_obat=?",[$_POST['nama_obat']]);
  //   if(count($find)==0){
  //     $nama_obat = $_POST['nama_obat'];
  //     $stock_obat = $_POST['stock_obat'];
  //     $harga = $_POST['harga'];
  //     $nama_pengguna_dokter = $_POST['nama_pengguna_dokter'];
  //     $input= DB::insert("INSERT INTO obat (nama_obat, stock_obat, harga, nama_pengguna_dokter ) VALUES (?,?,?,?)",[$nama_obat, $stock_obat, $harga, $nama_pengguna_dokter]);
  //  }else {
  //    echo "<script>alert('DATA SUDAH ADA.')</script>";
  //    return view('obat', ['data' => $find]);
  //  }
  //  echo "<script>alert('BERHASIL DAFTAR.')</script>";
  //    return view('home_dokter');
  // }
  //
  // //hapus obat
  // public function hapus(){
  //   $finf=DB::table('obat')->delete();
  //   echo "<script>alert('BERHASIL DI Hapus.')</script>";
  //     return view('editObatq', ['data' => $find]);
  // }

  public function index()
  {
    // mengambil data dari table pegawai
    $pegawai = DB::table('obat')->get();

    // mengirim data pegawai ke view index
    return view('index',['obat' => $obat]);

  }
}
