<!DOCTYPE html>
<html>
<head>
	<title>Tutorial Membuat CRUD Pada Laravel - www.malasngoding.com</title>
</head>
<body>

	<h2>www.malasngoding.com</h2>
	<h3>Data Pegawai</h3>

	<a href="/tampilan_obat/tambah"> + Tambah Pegawai Baru</a>

	<br/>
	<br/>

	<table border="1">
		<tr>
			<th>Nama Obat</th>
			<th>Stock Obat</th>
			<th>Harga</th>
			<th>Nama Dokter</th>
			<th>Opsi</th>
		</tr>
		<?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($o->nama_obat); ?></td>
			<td><?php echo e($o->stock_obat); ?></td>
			<td><?php echo e($o->harga); ?></td>
			<td><?php echo e($o->nama_pengguna_dokter); ?></td>
			<td>
				<a href="/tampilan_obat/edit/<?php echo e($o->id); ?>">Edit</a>
				<a href="/tampilan_obat/hapus/<?php echo e($o->id); ?>">Hapus</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\ppl\resources\views/obat.blade.php ENDPATH**/ ?>