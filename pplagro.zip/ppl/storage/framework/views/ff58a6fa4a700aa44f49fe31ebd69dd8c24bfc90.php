<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>PROFIL</title>
  </head>
  <body>
  <form action="<?php echo e(route('editproses')); ?>">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="text" name="hasil" value='<?php echo e($nama->nama_pengguna); ?>'>
    <input type="text" name="hasil1" value='<?php echo e($nama->nama); ?>'>
    <input type="text" name="hasil2" value='<?php echo e($nama->kata_sandi); ?>'>
    <input type="text" name="hasil3" value='<?php echo e($nama->tanggal_lahir); ?>'>
    <input type="text" name="hasil4" value='<?php echo e($nama->alamat); ?>'>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <input id="submit-btn" type="submit" name="submit" value="SIMPAN" />
  </form>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\ppl\resources\views/editprofil.blade.php ENDPATH**/ ?>