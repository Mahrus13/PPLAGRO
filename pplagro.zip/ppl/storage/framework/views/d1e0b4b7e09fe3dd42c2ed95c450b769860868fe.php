<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/home.css">
    <title>Si Sapi</title>
  </head>
  <body>
    <ul>
    <li class="dropdown">
      <a class="dropbtn"></a>
      <div class="dropdown-content">
        <a href="#">Profil Saya</a>
        <a href="login">Keluar</a>
      </div>
    </li>
  </ul>
    <?php echo $__env->yieldContent('content'); ?>
    <div class="box1"></div>
		<div class="box2"></div>
		<div class="box3"></div>
    <div class="box4"></div>
    <div class="judul1">DOKTER</div>
    <div class="judul2">OBAT</div>
    <div class="judul3">PAKAR</div>
    <div class="judul4">PESAN</div>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\ppl\resources\views/home.blade.php ENDPATH**/ ?>