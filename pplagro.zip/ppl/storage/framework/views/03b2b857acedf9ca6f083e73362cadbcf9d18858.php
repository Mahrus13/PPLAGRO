<title>MASUK</title>
<?php $__env->startSection('content'); ?>
<div id="card-content">
    <div id="card-title">
    <h2>MASUK</h2>
    <div class="underline-title"></div>
    </div>
</div>
<form method="POST" class="form" action="<?php echo e(route('prosesUser1')); ?>">
  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <label for="nama_pengguna" style="padding-top:13px">&nbsp;Nama Pengguna</label>
    <input id="nama_pengguna" class="form-content" type="text" name="nama_pengguna"required />
    <div class="form-border"></div>
    <label for="kata_sandi" style="padding-top:22px">&nbsp;Kata Sandi</label>
    <input id="kata_sandi"class="form-content" type="password" name="kata_sandi" required />
    <div class="form-border"></div>
    <a href="lupa"><legend id="forgot-pass">Lupa Kata Sandi?</legend></a>
    <input id="submit-btn" type="submit" name="submit" value="MASUK" /><a href="daftar" id="signup">Belum Punya Akun?</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ppl\resources\views/login.blade.php ENDPATH**/ ?>