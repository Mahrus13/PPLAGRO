<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>PROFIL</title>
  </head>
  <body>
    <table border="1px">
      <tr>
        <td>nama pengguna</td>
        <td>nama</td>
        <td>kata sandi</td>
        <td>tanggal lahir</td>
        <td>alamats</td>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <td><?php echo e($nama->nama_pengguna); ?></td>
              <td><?php echo e($nama->nama); ?></td>
              <td><?php echo e($nama->kata_sandi); ?></td>
              <td><?php echo e($nama->tanggal_lahir); ?></td>
              <td><?php echo e($nama->alamat); ?></td>
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tr>
    </table>
    <a href="<?php echo e(route('editq')); ?>"> <input type="submit" name="" value="EDIT"> </a>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\ppl\resources\views/profile.blade.php ENDPATH**/ ?>