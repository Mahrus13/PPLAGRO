<title>DAFTAR</title>
<?php $__env->startSection('content'); ?>
<div id="card-content">
    <div id="card-title">
    <h2>PENDAFTARAN</h2>
    <div class="underline-titlea"></div>
    </div>
</div>
<form method="POST" class="form" action="<?php echo e(route('prosesUser')); ?>">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <label for="nama_pengguna" style="padding-top:13px">&nbsp;Nama Pengguna</label>
    <input id="nama_pengguna" class="form-content" type="text" name="nama_pengguna"required />
    <div class="form-border"></div>
    <label for="nama" style="padding-top:13px">&nbsp;Nama</label>
    <input id="nama" class="form-content" type="text" name="nama"required />
    <div class="form-border"></div>
    <label for="kata_sandi" style="padding-top:22px">&nbsp;Kata Sandi</label>
    <input id="kata_sandi"class="form-content" type="password" name="kata_sandi" required />
    <div class="form-border"></div>
    <label for="alamat" style="padding-top:13px">&nbsp;Alamat</label>
    <input id="alamat" class="form-content" type="text" name="alamat"required />
    <div class="form-border"></div>
    <input id="submit-btn" type="submit" name="submit" value="DAFTAR" />
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ppl\resources\views/daftar.blade.php ENDPATH**/ ?>