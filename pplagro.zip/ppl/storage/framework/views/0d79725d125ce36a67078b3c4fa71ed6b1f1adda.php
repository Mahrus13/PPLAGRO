<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<h3>Data Obat</h3>

	<a href="/tampilan_obat"> Kembali</a>

	<br/>
	<br/>

	<form action="/tampilan_obat/store" method="post">
		<?php echo e(csrf_field()); ?>

		Nama Obat <input type="text" name="nama_obat" required="required"> <br/>
		Stock Obat <input type="number" name="stock_obat" required="required"> <br/>
		Harga <input type="number" name="harga" required="required"> <br/>
		Nama Dokter <input type="text" name="nama_dokter" required="required"><br/>
		<input type="submit" value="Simpan Data">
	</form>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\ppl\resources\views/tambahObat.blade.php ENDPATH**/ ?>