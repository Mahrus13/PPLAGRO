<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


	<h3>Edit Obat</h3>

	<a href="/tampilan_obat"> Kembali</a>

	<br/>
	<br/>

	<?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<form action="/tampilan_obat/update" method="post">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="id" value="<?php echo e($o->id); ?>"> <br/>
		Nama Obat <input type="text" required="required" name="nama_obat" value="<?php echo e($o->nama_obat); ?>"> <br/>
		Stock Obat <input type="number" required="required" name="stock_obat" value="<?php echo e($o->stock_obat); ?>"> <br/>
		Harga <input type="number" required="required" name="harga" value="<?php echo e($o->harga); ?>"> <br/>
		Nama Dokter <input type="text" required="required" name="nama_dokter" value="<?php echo e($o->nama_pengguna_dokter); ?>"> <br/>
		<input type="submit" value="Simpan Data">
	</form>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\ppl\resources\views/editObat.blade.php ENDPATH**/ ?>