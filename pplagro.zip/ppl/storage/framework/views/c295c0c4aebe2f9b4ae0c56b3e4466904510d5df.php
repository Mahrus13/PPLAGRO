<title>SI SAPI</title>
<?php $__env->startSection('content'); ?>
<div id="card-content">
    <div id="card-title">
    <h2>MASUK SEBAGAI :</h2>
    <div class="underline-titleo"></div>
    </div>
</div>
  <a href="login_dokter"><button class="button button2">DOKTER</button> </a>
  <a href="login"> <button class="button button3">PETERNAK</button> </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ppl\resources\views/index.blade.php ENDPATH**/ ?>