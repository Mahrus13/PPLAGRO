<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>PROFIL</title>
  </head>
  <body>
    <!-- <table border="1px">
      <tr>
        <td>nama_pengguna</td>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <td><?php echo e($nama->nama_pengguna); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    </table>

    <a href="#"> <input type="submit" name="" value="EDIT"> </a> -->
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\ppl\resources\views/profil.blade.php ENDPATH**/ ?>