<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<h2>OBAT SAPI</h2>

	<a href="/tampilan_obat/tambahObat"> + Tambah Obat Baru</a>

	<br/>
	<br/>

	<table border="1">
		<tr>
			<th>Nama Obat</th>
			<th>Stock</th>
			<th>Harga</th>
			<th>Nama Dokter</th>
			<th>Opsi</th>
		</tr>
		<?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($o->nama_obat); ?></td>
			<td><?php echo e($o->stock_obat); ?></td>
			<td><?php echo e($o->harga); ?></td>
			<td><?php echo e($o->nama_pengguna_dokter); ?></td>
			<td>
				<a href="/tampilan_obat/edit/<?php echo e($o->id); ?>">Ubah</a>
				|
				<a href="/tampilan_obat/hapus/<?php echo e($o->id); ?>">Hapus</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<a href="home_dokter">Kembali</a>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\ppl\resources\views/tampilan_obat.blade.php ENDPATH**/ ?>