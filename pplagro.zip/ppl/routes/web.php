<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::get('login', function () {
    return view('login');
});
Route::get('daftar', function () {
    return view('daftar');
});
Route::get('lupa', function () {
    return view('lupa');
});
Route::get('index', function () {
    return view('index');
});
Route::get('login_dokter', function () {
    return view('login_dokter');
});
Route::get('home', function () {
    return view('home');
});
Route::get('home_dokter', function () {
    return view('home_dokter');
});
Route::get('editprofil', function () {
    return view('editprofil');
});
Route::get('profile', function () {
    return view('profile');
});
Route::get('editObat', function () {
    return view('editObat');
});
Route::get('obat', function () {
    return view('obat');
});
Route::get('tambahObat', function () {
    return view('tambahObat');
});
Route::get('ppl', function () {
    return view('ppl');
});

Route::get('/tampilan_obat','ObatController@index');
Route::get('/tampilan_obat/tambahObat','ObatController@tambah');
Route::post('/tampilan_obat/store','ObatController@store');
Route::get('/tampilan_obat/edit/{id}','ObatController@edit');
Route::post('/tampilan_obat/update','ObatController@update');
Route::get('/tampilan_obat/hapus/{id}','ObatController@hapus');

//edit profil
Route::get('edit','koneksi@edit')->name('edit');
Route::get('editq','koneksi@editq')->name('editq');
Route::get('editproses','koneksi@editproses')->name('editproses');
//edit obat
Route::get('editObat','koneksi@editObat')->name('editObat');
Route::get('editObatq','koneksi@editObatq')->name('editObatq');
Route::get('editproses1','koneksi@editproses1')->name('editproses1');
//tambahObat
Route::post('tambah','koneksi@tambah')->name('tambah');
//tampilan
Route::get('hapus','koneksi@hapus')->name('hapus');
Route::post('prosesUser','koneksi@proses')->name('prosesUser');
Route::post('prosesUser1','koneksi@proses1')->name('prosesUser1');
Route::post('prosesUser2','koneksi@proses2')->name('prosesUser2');
